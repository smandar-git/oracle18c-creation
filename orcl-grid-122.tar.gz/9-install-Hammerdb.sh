cd /home/oracle
zcat /root/scripts/HammerDB-3.1-Linux.tar.gz | tar -xvf - 
chown -R oracle:oinstall HammerDB-3.1/
cd
