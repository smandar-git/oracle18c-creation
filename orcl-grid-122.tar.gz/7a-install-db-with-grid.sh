# run as oracle user
. ./.bash_profile
/sw/database/runInstaller -silent  -ignorePrereqFailure  -waitforcompletion -showProgress -responseFile /home/oracle/install-db-with-grid.rsp
