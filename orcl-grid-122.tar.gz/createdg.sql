CREATE DISKGROUP DATADG EXTERNAL REDUNDANCY DISK '/dev/oracleasm/disks/DATADG' attribute 'au_size' = '1M' , 'compatible.asm' = '12.1' , 'compatible.rdbms' = '12.1' ;
CREATE DISKGROUP ARCHDG EXTERNAL REDUNDANCY DISK '/dev/oracleasm/disks/ARCHDG' attribute 'au_size' = '1M' , 'compatible.asm' = '12.1' , 'compatible.rdbms' = '12.1' ;
CREATE DISKGROUP RECODG EXTERNAL REDUNDANCY DISK '/dev/oracleasm/disks/RECODG' attribute 'au_size' = '1M' , 'compatible.asm' = '12.1' , 'compatible.rdbms' = '12.1' ;
