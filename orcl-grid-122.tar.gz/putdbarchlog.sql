shutdown immediate
startup mount
alter database archivelog;
alter database open;
archive log list;

