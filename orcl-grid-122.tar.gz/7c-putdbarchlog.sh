sqlplus / as sysdba <<EOF
@putdbarchlog.sql;
EOF
