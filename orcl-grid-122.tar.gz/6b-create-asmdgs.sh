sqlplus / as sysasm <<EOF
@createdg.sql;
EOF
