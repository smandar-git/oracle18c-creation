cd /u01/app/12.2.0/grid
./gridSetup.sh  -silent  -ignorePrereqFailure -waitforcompletion  -responseFile /home/grid/install-grid1.rsp
