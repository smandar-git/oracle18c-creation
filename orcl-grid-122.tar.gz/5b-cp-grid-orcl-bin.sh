#this script expects oracle and grid binaries in /sw

cd /sw 
unzip V839960-01.zip
chown -R oracle:oinstall database

mkdir -p /u01/app/12.2.0/grid
cd /u01/app/12.2.0/grid
unzip /sw/V840012-01.zip
chown -R grid:asmadmin /u01
